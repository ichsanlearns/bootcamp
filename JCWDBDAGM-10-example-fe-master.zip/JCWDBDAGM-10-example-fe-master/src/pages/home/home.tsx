import JumbotronSection from "./sections/jumbotron/jumbotron";

export default function Home() {
  return (
    <>
      <JumbotronSection />
    </>
  );
}
