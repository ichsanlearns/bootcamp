export interface ITodo {
  name: string;
  isCompleted: boolean;
}
